package com.bookclub.bookstore.model;

public class TopBookSales {
	Integer booksSold;
	String title;
	Integer bookId;
	
	public Integer getBooksSold() {
		return booksSold;
	}
	public void setBooksSold(Integer booksSold) {
		this.booksSold = booksSold;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Integer getBookId() {
		return bookId;
	}
	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}
	
	
}
